# domy
software and description home automation system by Homatron

This software is based on panstamp and is experienced to work with devices made by Homatron (http://www.homatron.it).

It works as a lot of microservices communicating with each other via message queuing MQTT using MosquittoPHP and PAHO (python). 

Also the GUI is in system with use of websocket in standard MQTT from 3.1 version.

GUI is based on a simple mechanism of svg widgets each one containing all the animation and transmission system to work alone and inside an html container. html has only the responsability to recognize topics and forward the relative message to the widget. The widget can act a command sending it through send method of html. 
