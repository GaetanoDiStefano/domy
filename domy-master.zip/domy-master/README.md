# domy
software and description home automation system by Homatron

This software is based on panstamp and is experienced to work with devices made by Homatron (http://www.homatron.it).

It works as a lot of microservices communicating with each other via message queuing MQTT using MosquittoPHP and PAHO (python). Also the GUI is in system with use of websocket in standard MQTT from 3.1 version.
